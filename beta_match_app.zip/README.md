# Beta Match App

אפליקציה לשידוכים לקהילת ביתא ישראל.

## איך להפעיל מקומית

1. `npm install`
2. `npm run dev`

## איך להעלות ל-Vercel

1. היכנסי ל-Vercel
2. לחצי על Import Project
3. בחרי את הריפו מ-GitHub
4. לחצי Deploy
